var modules = {
		view : fn.noaccess,
		add : fn.noaccess,
		edit : fn.noaccess,
		dialog_remove : fn.noaccess,
		remove : fn.noaccess,
		lookup : fn.noaccess,
};
$.extend(fn.app,{cloud:modules});
